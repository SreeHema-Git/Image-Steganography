#ifndef TYPESDECODE_H
#define TYPESDECODE_H

/* User defined types */
typedef unsigned int uint;

/* Status will be used in fn. return type */
typedef enum
{
    d_failure,//0
    d_success//1
} Statusdecode;




#endif
